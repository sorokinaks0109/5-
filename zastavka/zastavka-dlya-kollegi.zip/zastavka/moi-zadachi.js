/* Задачи для заставки «Мой рабочий стол». Не переименовывайте файл и держите его рядом с заставкой. */
window.MOI_ZADACHI = {
 "name": "",
 "focus": "",
 "notes": "",
 "season": "auto",
 "light": "auto",
 "filter": "all",
 "showDone": false,
 "savedAt": 0,
 "projects": [],
 "tasks": []
};
